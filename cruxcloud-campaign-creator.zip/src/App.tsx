import React, { useState } from "react";
import {
  Currency,
  HostingCategory,
  HostingPlan,
  Language,
  MinecraftThemeMode,
} from "./types";
import { MinecraftBackground } from "./components/MinecraftBackground";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { HostingPlans } from "./components/HostingPlans";
import { CustomCalculator } from "./components/CustomCalculator";
import { NodeLocations } from "./components/NodeLocations";
import { Footer } from "./components/Footer";
import { OrderModal } from "./components/OrderModal";
import { AiChatbot } from "./components/AiChatbot";
import { BannerStudio } from "./components/BannerStudio";
import { playMinecraftClick } from "./utils/audio";
import { BOT_PLANS } from "./data/hostingData";
import { MessageSquareCode, Image as ImageIcon } from "lucide-react";

export default function App() {
  const [theme, setTheme] = useState<MinecraftThemeMode>("overworld_night");
  const [language, setLanguage] = useState<Language>("en");
  const [currency, setCurrency] = useState<Currency>("INR");
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [activeCategory, setActiveCategory] = useState<HostingCategory>("bot");

  // Modals state
  const [isDeployModalOpen, setIsDeployModalOpen] = useState<boolean>(false);
  const [selectedPlan, setSelectedPlan] = useState<HostingPlan | null>(BOT_PLANS[1]); // Default to Redstone Bot Pro
  const [isAiChatOpen, setIsAiChatOpen] = useState<boolean>(false);
  const [isBannerStudioOpen, setIsBannerStudioOpen] = useState<boolean>(false);

  const handleOpenDeployForPlan = (plan: HostingPlan) => {
    setSelectedPlan(plan);
    setIsDeployModalOpen(true);
  };

  const handleOpenDeployDefault = () => {
    if (!selectedPlan) {
      setSelectedPlan(BOT_PLANS[1]);
    }
    setIsDeployModalOpen(true);
  };

  return (
    <div className="min-h-screen text-slate-100 relative font-sans flex flex-col selection:bg-emerald-500 selection:text-black">
      {/* 3D Animated Minecraft Canvas & Atmospheric Sky */}
      <MinecraftBackground theme={theme} />

      {/* Top Navbar */}
      <Navbar
        theme={theme}
        setTheme={setTheme}
        language={language}
        setLanguage={setLanguage}
        currency={currency}
        setCurrency={setCurrency}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        onOpenAiChat={() => setIsAiChatOpen(true)}
        onOpenBannerStudio={() => setIsBannerStudioOpen(true)}
        onOpenDeployModal={handleOpenDeployDefault}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          language={language}
          currency={currency}
          onSelectCategory={(cat) => setActiveCategory(cat)}
          onOpenDeployModal={handleOpenDeployDefault}
          onOpenAiChat={() => setIsAiChatOpen(true)}
          onOpenBannerStudio={() => setIsBannerStudioOpen(true)}
        />

        {/* 3 Products / Categories & Plans: Bot, VPS, Web */}
        <HostingPlans
          activeCategory={activeCategory}
          setActiveCategory={setActiveCategory}
          language={language}
          currency={currency}
          onSelectPlan={handleOpenDeployForPlan}
        />

        {/* Custom Server Resource Slider / Calculator */}
        <CustomCalculator
          language={language}
          currency={currency}
          onDeployCustomPlan={handleOpenDeployForPlan}
        />

        {/* Global Node Latency Monitor */}
        <NodeLocations language={language} />
      </main>

      {/* Themed Footer */}
      <Footer
        language={language}
        onOpenDeployModal={handleOpenDeployDefault}
        onOpenAiChat={() => setIsAiChatOpen(true)}
        onOpenBannerStudio={() => setIsBannerStudioOpen(true)}
      />

      {/* Floating Action Quick Access Dock - Smooth rounded pills */}
      <div className="fixed bottom-5 right-5 z-40 flex flex-col gap-2.5 items-end">
        {/* AI Banner Studio Quick Button */}
        <button
          onClick={() => {
            playMinecraftClick();
            setIsBannerStudioOpen(true);
          }}
          className="flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-purple-950/85 hover:bg-purple-900 text-purple-200 border border-purple-400/50 shadow-[0_4px_20px_rgba(168,85,247,0.35)] backdrop-blur-xl text-xs font-mono transition-all cursor-pointer hover:scale-105"
          title="Create custom server Banners & 4K Campaign Art"
        >
          <ImageIcon size={15} className="text-purple-400" />
          <span className="hidden sm:inline font-semibold">
            {language === "hi" ? "AI बैनर स्टूडियो (4K)" : "4K Visual Studio"}
          </span>
        </button>

        {/* AI Chatbot Assistant Floating Button */}
        <button
          onClick={() => {
            playMinecraftClick();
            setIsAiChatOpen(true);
          }}
          className="flex items-center gap-2.5 px-4.5 py-3 rounded-full bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 text-slate-950 border border-emerald-300 shadow-[0_4px_25px_rgba(16,185,129,0.45)] font-mono text-xs font-bold uppercase tracking-wider transition-all cursor-pointer hover:scale-105"
          title="Ask Crux AI Server Architect"
        >
          <MessageSquareCode size={16} />
          <span>{language === "hi" ? "क्रुक्स AI सपोर्ट" : "Ask Crux AI"}</span>
        </button>
      </div>

      {/* Deployment & Order Configuration Modal */}
      <OrderModal
        plan={selectedPlan}
        isOpen={isDeployModalOpen}
        onClose={() => setIsDeployModalOpen(false)}
        language={language}
        currency={currency}
      />

      {/* Gemini Multi-turn Chatbot Modal */}
      <AiChatbot
        isOpen={isAiChatOpen}
        onClose={() => setIsAiChatOpen(false)}
        language={language}
      />

      {/* Gemini 4K Banner & Campaign Visual Studio Modal */}
      <BannerStudio
        isOpen={isBannerStudioOpen}
        onClose={() => setIsBannerStudioOpen(false)}
        language={language}
      />
    </div>
  );
}
