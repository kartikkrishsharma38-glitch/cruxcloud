import React, { useState } from "react";
import { HostingPlan, Language, Currency } from "../types";
import { DEPLOY_RUNTIME_OPTIONS, SERVER_LOCATIONS } from "../data/hostingData";
import { playMinecraftClick, playLevelUpSound } from "../utils/audio";
import {
  X,
  Check,
  Server,
  Terminal,
  Shield,
  Zap,
  Globe,
  HardDrive,
  Copy,
  ExternalLink,
  CheckCircle2,
  Cpu,
  Bot,
} from "lucide-react";

interface Props {
  plan: HostingPlan | null;
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  currency: Currency;
}

export const OrderModal: React.FC<Props> = ({
  plan,
  isOpen,
  onClose,
  language,
  currency,
}) => {
  const isHi = language === "hi";

  const [serverName, setServerName] = useState("crux-bot-service");
  const [subdomain, setSubdomain] = useState("mybot");
  const [selectedSoftware, setSelectedSoftware] = useState("nodejs");
  const [selectedLocation, setSelectedLocation] = useState("in-mum-01");
  const [dedicatedIp, setDedicatedIp] = useState(false);
  const [isProvisioning, setIsProvisioning] = useState(false);
  const [provisionProgress, setProvisionProgress] = useState(0);
  const [provisionLog, setProvisionLog] = useState<string[]>([]);
  const [isCompleted, setIsCompleted] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  if (!isOpen || !plan) return null;

  const basePrice = currency === "INR" ? plan.priceINR : plan.priceUSD;
  const addonPrice = dedicatedIp ? (currency === "INR" ? 149 : 1.99) : 0;
  const totalPrice = currency === "INR" ? basePrice + addonPrice : (basePrice + addonPrice).toFixed(2);

  const handleStartDeploy = () => {
    playMinecraftClick();
    setIsProvisioning(true);
    setProvisionProgress(10);
    setProvisionLog([`[1/5] Contacting hypervisor daemon at node ${selectedLocation}...`]);

    setTimeout(() => {
      setProvisionProgress(35);
      setProvisionLog((prev) => [
        ...prev,
        `[2/5] Allocating hardware: ${plan.ram} RAM & ${plan.cpu}...`,
      ]);
    }, 700);

    setTimeout(() => {
      setProvisionProgress(65);
      setProvisionLog((prev) => [
        ...prev,
        `[3/5] Partitioning NVMe SSD (${plan.storage}) & binding 2.5 Tbps DDoS Shield...`,
      ]);
    }, 1500);

    setTimeout(() => {
      setProvisionProgress(85);
      setProvisionLog((prev) => [
        ...prev,
        `[4/5] Deploying runtime environment (${selectedSoftware}) & configuring DNS...`,
      ]);
    }, 2200);

    setTimeout(() => {
      playLevelUpSound();
      setProvisionProgress(100);
      setProvisionLog((prev) => [
        ...prev,
        `[5/5] Instance ONLINE at ${subdomain}.cruxcloud.net! Web terminal & panel ready.`,
      ]);
      setIsCompleted(true);
    }, 3000);
  };

  const copyToClipboard = (text: string, fieldId: string) => {
    playMinecraftClick();
    navigator.clipboard.writeText(text);
    setCopiedField(fieldId);
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      {/* Modal Container - Smooth rounded-2xl glassmorphism */}
      <div className="relative w-full max-w-xl max-h-[92vh] flex flex-col rounded-2xl overflow-hidden backdrop-blur-2xl bg-slate-950/90 border border-emerald-500/40 shadow-[0_15px_50px_rgba(0,0,0,0.8)]">
        {/* Sleek top accent line */}
        <div className="h-1.5 w-full bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400" />

        {/* Modal Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Zap size={17} />
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
                <span>{isHi ? "क्रुक्स सर्वर इंस्टेंस डिप्लॉय" : "CRUX CLOUD INSTANT DEPLOY"}</span>
              </h3>
              <p className="text-[11px] text-slate-400 font-sans">
                {isHi ? "AMD EPYC हाई-स्पीड नोड प्रोविजनिंग" : "AMD EPYC High-Speed Cloud Node Provisioning"}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              playMinecraftClick();
              onClose();
            }}
            className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-5 font-sans">
          {!isCompleted ? (
            <>
              {/* Plan Summary Banner */}
              <div className="p-4 rounded-xl bg-slate-900/80 border border-emerald-500/30 flex flex-wrap items-center justify-between gap-3 shadow-inner">
                <div>
                  <div className="font-mono text-xs text-emerald-400 uppercase font-bold">
                    {isHi ? plan.nameHi : plan.name}
                  </div>
                  <div className="text-xs text-slate-300 mt-0.5">
                    {plan.ram} • {plan.cpu} • {plan.storage}
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-2xl font-extrabold font-mono text-white">
                    {currency === "INR" ? `₹${totalPrice}` : `$${totalPrice}`}
                    <span className="text-xs text-slate-400 font-normal">/mo</span>
                  </div>
                  <div className="text-[10px] font-mono text-emerald-400">
                    {isHi ? "2.5 Tbps DDoS शील्ड एक्टिव" : "2.5 Tbps DDoS Shield Active"}
                  </div>
                </div>
              </div>

              {!isProvisioning ? (
                <>
                  {/* Server Details Inputs */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Server Name */}
                    <div>
                      <label className="block text-xs font-mono text-slate-300 mb-1.5">
                        {isHi ? "सर्वर लेबल / नाम:" : "Instance Label / Name:"}
                      </label>
                      <input
                        type="text"
                        value={serverName}
                        onChange={(e) => setServerName(e.target.value)}
                        className="w-full bg-slate-900/90 border border-white/15 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-hidden focus:border-emerald-400"
                        placeholder="e.g. crux-bot-cluster"
                      />
                    </div>

                    {/* Subdomain */}
                    <div>
                      <label className="block text-xs font-mono text-slate-300 mb-1.5">
                        {isHi ? "फ्री सबडोमेन:" : "Free Custom Subdomain:"}
                      </label>
                      <div className="flex items-center">
                        <input
                          type="text"
                          value={subdomain}
                          onChange={(e) => setSubdomain(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""))}
                          className="flex-1 bg-slate-900/90 border border-white/15 rounded-l-xl px-3 py-2 text-xs font-mono text-white focus:outline-hidden focus:border-emerald-400"
                          placeholder="mybot"
                        />
                        <span className="bg-slate-800 border border-l-0 border-white/15 px-2.5 py-2 text-xs font-mono text-slate-300 rounded-r-xl">
                          .cruxcloud.net
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Node Location */}
                  <div>
                    <label className="block text-xs font-mono text-slate-300 mb-1.5 flex items-center gap-1.5">
                      <Globe size={13} className="text-cyan-400" />
                      <span>{isHi ? "डेटासेंटर लोकेशन:" : "Datacenter Node Location:"}</span>
                    </label>
                    <select
                      value={selectedLocation}
                      onChange={(e) => setSelectedLocation(e.target.value)}
                      className="w-full bg-slate-900/90 border border-white/15 rounded-xl px-3 py-2.5 text-xs font-mono text-white focus:outline-hidden focus:border-emerald-400"
                    >
                      {SERVER_LOCATIONS.map((loc) => (
                        <option key={loc.id} value={loc.id}>
                          {loc.flag} {loc.name} ({loc.code}) — {loc.ping}ms Ping
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Runtime Engine Choice */}
                  <div>
                    <label className="block text-xs font-mono text-slate-300 mb-1.5 flex items-center gap-1.5">
                      <Terminal size={13} className="text-amber-400" />
                      <span>{isHi ? "सॉफ्टवेयर / ऑपरेटिंग वातावरण:" : "Runtime / Operating Environment:"}</span>
                    </label>
                    <select
                      value={selectedSoftware}
                      onChange={(e) => setSelectedSoftware(e.target.value)}
                      className="w-full bg-slate-900/90 border border-white/15 rounded-xl px-3 py-2.5 text-xs font-mono text-white focus:outline-hidden focus:border-emerald-400"
                    >
                      {DEPLOY_RUNTIME_OPTIONS.map((opt) => (
                        <option key={opt.id} value={opt.id}>
                          {opt.name} — {opt.desc}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Addon: Dedicated Static IPv4 */}
                  <div className="p-3 bg-slate-900/60 rounded-xl border border-white/10 space-y-2">
                    <label className="flex items-center gap-2.5 text-xs font-mono text-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={dedicatedIp}
                        onChange={(e) => setDedicatedIp(e.target.checked)}
                        className="accent-emerald-500 rounded-md w-4 h-4"
                      />
                      <span>
                        {isHi ? "डेडिकेटेड स्टैटिक IPv4 एड्रेस (+₹149/माह)" : "Add Dedicated Static IPv4 (+₹149 / $1.99/mo)"}
                      </span>
                    </label>
                  </div>

                  {/* Start Provisioning CTA */}
                  <button
                    onClick={handleStartDeploy}
                    className="w-full py-3.5 px-4 rounded-xl font-mono text-sm font-bold bg-gradient-to-r from-emerald-400 via-teal-400 to-emerald-500 hover:from-emerald-300 hover:to-teal-300 text-slate-950 flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(16,185,129,0.4)] transition-all cursor-pointer hover:scale-[1.01]"
                  >
                    <Zap size={16} className="fill-slate-950" />
                    <span>{isHi ? "तुरंत सर्वर सेटअप शुरू करें" : "PROVISION INSTANCE NOW"}</span>
                  </button>
                </>
              ) : (
                /* Provisioning Terminal Log View */
                <div className="space-y-4 py-4">
                  <div className="flex items-center justify-between text-xs font-mono text-slate-300">
                    <span>Provisioning in progress...</span>
                    <span className="text-emerald-400 font-bold">{provisionProgress}%</span>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-white/10">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400 transition-all duration-300"
                      style={{ width: `${provisionProgress}%` }}
                    />
                  </div>

                  {/* Terminal Log Output */}
                  <div className="bg-black/90 p-4 rounded-xl border border-emerald-500/30 font-mono text-[11px] text-emerald-300 space-y-1.5 h-40 overflow-y-auto">
                    {provisionLog.map((log, i) => (
                      <div key={i} className="flex items-center gap-1.5">
                        <span className="text-slate-500">&gt;</span>
                        <span>{log}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            /* Success View */
            <div className="text-center py-4 space-y-6">
              <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border-2 border-emerald-400 mx-auto flex items-center justify-center text-emerald-400 shadow-[0_0_30px_rgba(16,185,129,0.5)]">
                <CheckCircle2 size={36} />
              </div>

              <div>
                <h4 className="text-xl font-bold text-white font-mono mb-1">
                  {isHi ? "सर्वर सफलतापूर्वक एक्टिवेट हो गया है!" : "INSTANCE IS ONLINE & READY!"}
                </h4>
                <p className="text-xs text-slate-300">
                  {isHi
                    ? "आपका क्लाउड सर्वर लाइव है। आप नीचे दिए गए पते से सीधे कनेक्ट या कंट्रोल पैनल खोल सकते हैं।"
                    : "Your Crux Cloud instance has been deployed with dedicated hardware."}
                </p>
              </div>

              {/* Server Credentials Box */}
              <div className="p-4 rounded-xl bg-slate-900/90 border border-emerald-500/40 text-left font-mono text-xs space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <span className="text-slate-400">Server Endpoint:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-300 font-bold">{subdomain}.cruxcloud.net</span>
                    <button
                      onClick={() => copyToClipboard(`${subdomain}.cruxcloud.net`, "ip")}
                      className="text-slate-400 hover:text-white"
                    >
                      {copiedField === "ip" ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <span className="text-slate-400">Control Panel:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-cyan-300">https://panel.cruxcloud.net</span>
                    <button
                      onClick={() => copyToClipboard("https://panel.cruxcloud.net", "panel")}
                      className="text-slate-400 hover:text-white"
                    >
                      {copiedField === "panel" ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400">SSH / SFTP Access:</span>
                  <span className="text-white">ssh root@{subdomain}.cruxcloud.net -p 22</span>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    playMinecraftClick();
                    onClose();
                  }}
                  className="flex-1 py-3 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs font-bold transition-colors cursor-pointer"
                >
                  {isHi ? "बंद करें" : "Close Wizard"}
                </button>

                <button
                  onClick={() => {
                    playMinecraftClick();
                    window.open("https://panel.cruxcloud.net", "_blank");
                  }}
                  className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 text-slate-950 font-mono text-xs font-bold uppercase transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
                >
                  <span>{isHi ? "कंट्रोल पैनल खोलें" : "Open Web Panel"}</span>
                  <ExternalLink size={13} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
