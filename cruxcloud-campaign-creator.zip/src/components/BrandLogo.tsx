import React from "react";

interface Props {
  size?: number;
  className?: string;
}

export const BrandLogo: React.FC<Props> = ({ size = 40, className = "" }) => {
  return (
    <div
      className={`relative inline-flex items-center justify-center rounded-xl overflow-hidden shadow-lg border border-emerald-500/30 ${className}`}
      style={{ width: size, height: size }}
    >
      <img
        src="/assets/crux-logo.svg"
        alt="Crux Cloud Logo"
        className="w-full h-full object-cover select-none"
        loading="eager"
      />
    </div>
  );
};
