import React from "react";
import { Language } from "../types";
import { playMinecraftClick } from "../utils/audio";
import { Sparkles, Shield, Bot, Cpu, Globe } from "lucide-react";
import { BrandLogo } from "./BrandLogo";

interface Props {
  language: Language;
  onOpenDeployModal: () => void;
  onOpenAiChat: () => void;
  onOpenBannerStudio: () => void;
}

export const Footer: React.FC<Props> = ({
  language,
  onOpenDeployModal,
  onOpenAiChat,
  onOpenBannerStudio,
}) => {
  const isHi = language === "hi";

  return (
    <footer className="relative z-10 bg-slate-950/85 backdrop-blur-xl border-t border-emerald-500/20 pt-14 pb-10 text-slate-400 font-sans text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand Col */}
          <div className="md:col-span-1 space-y-3">
            <div className="flex items-center gap-3">
              <BrandLogo size={36} />
              <span className="font-['Silkscreen',monospace] text-base font-bold text-white tracking-wider">
                CRUX CLOUD
              </span>
            </div>

            <p className="text-slate-400 leading-relaxed text-xs">
              {isHi
                ? "क्रुक्स क्लाउड - प्रीमियम बॉट, वीपीएस व क्लाउड होस्टिंग। बिना किसी रुकावट या डाउनटाइम के अपने प्रोजेक्ट्स चलाएं।"
                : "Enterprise Discord Bot, Cloud VPS and Web application hosting with AMD EPYC 9654, NVMe Gen4 and 2.5 Tbps Anti-DDoS protection."}
            </p>

            <div className="flex items-center gap-2 pt-1 font-mono text-[11px] text-emerald-400">
              <Shield size={13} />
              <span>{isHi ? "2.5 Tbps एंटी-DDoS शील्ड" : "2.5 Tbps Anti-DDoS Protected"}</span>
            </div>
          </div>

          {/* Bot Hosting Services */}
          <div>
            <h4 className="font-mono text-white text-xs font-bold uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Bot size={14} className="text-emerald-400" />
              <span>{isHi ? "बॉट होस्टिंग" : "Bot Hosting"}</span>
            </h4>
            <ul className="space-y-2 font-mono text-[11px]">
              <li>
                <a href="#plans" onClick={playMinecraftClick} className="hover:text-emerald-300 transition-colors">
                  {isHi ? "पिक्सेल बोट (512MB RAM)" : "Pixel Bot Starter (512MB)"}
                </a>
              </li>
              <li>
                <a href="#plans" onClick={playMinecraftClick} className="hover:text-emerald-300 transition-colors">
                  {isHi ? "रेडस्टोन बोट प्रो (2GB) - लोकप्रिय" : "Redstone Bot Pro (2GB) - Popular"}
                </a>
              </li>
              <li>
                <a href="#plans" onClick={playMinecraftClick} className="hover:text-emerald-300 transition-colors">
                  {isHi ? "एंडर कोर क्लस्टर (4GB)" : "Ender Core Cluster (4GB)"}
                </a>
              </li>
              <li>
                <a href="#plans" onClick={playMinecraftClick} className="hover:text-emerald-300 transition-colors">
                  {isHi ? "क्वांटम शार्ड मास्टर (8GB)" : "Quantum Shard Master (8GB)"}
                </a>
              </li>
            </ul>
          </div>

          {/* Cloud VPS & Web */}
          <div>
            <h4 className="font-mono text-white text-xs font-bold uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Cpu size={14} className="text-cyan-400" />
              <span>{isHi ? "क्लाउड वीपीएस व वेब" : "Cloud VPS & Web Apps"}</span>
            </h4>
            <ul className="space-y-2 font-mono text-[11px]">
              <li>
                <a href="#plans" onClick={playMinecraftClick} className="hover:text-cyan-300 transition-colors">
                  {isHi ? "क्लाउड वीपीएस माइक्रो (Root KVM)" : "Cloud VPS Micro (1 Core / 2GB)"}
                </a>
              </li>
              <li>
                <a href="#plans" onClick={playMinecraftClick} className="hover:text-cyan-300 transition-colors">
                  {isHi ? "क्लाउड वीपीएस टर्बो (2 Core / 4GB)" : "Cloud VPS Turbo (2 Cores / 4GB)"}
                </a>
              </li>
              <li>
                <a href="#plans" onClick={playMinecraftClick} className="hover:text-purple-300 transition-colors">
                  {isHi ? "वेब क्लाउड स्टार्टर (Node/Python)" : "Web Cloud Starter (Node/Python)"}
                </a>
              </li>
              <li>
                <a href="#plans" onClick={playMinecraftClick} className="hover:text-purple-300 transition-colors">
                  {isHi ? "वेब क्लस्टर एंटरप्राइज (Docker)" : "Web Cluster Enterprise (Docker)"}
                </a>
              </li>
            </ul>
          </div>

          {/* AI Tools & Extras */}
          <div>
            <h4 className="font-mono text-white text-xs font-bold uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Sparkles size={14} className="text-purple-400" />
              <span>{isHi ? "AI टूल्स व सहायता" : "AI Tools & Support"}</span>
            </h4>
            <ul className="space-y-2 font-mono text-[11px]">
              <li>
                <button onClick={onOpenAiChat} className="hover:text-cyan-300 transition-colors text-left cursor-pointer">
                  {isHi ? "क्रुक्स AI चैटबॉट (सपोर्ट)" : "Crux AI Chatbot (24/7 Architect)"}
                </button>
              </li>
              <li>
                <button onClick={onOpenBannerStudio} className="hover:text-purple-300 transition-colors text-left cursor-pointer">
                  {isHi ? "AI बैनर व 4K विज़ुअल्स" : "AI Server Banner Studio (4K)"}
                </button>
              </li>
              <li>
                <a href="#calculator" onClick={playMinecraftClick} className="hover:text-amber-300 transition-colors">
                  {isHi ? "कस्टम रिसोर्स कैलकुलेटर" : "Custom Spec Calculator"}
                </a>
              </li>
              <li>
                <a href="#locations" onClick={playMinecraftClick} className="hover:text-emerald-300 transition-colors">
                  {isHi ? "ग्लोबल सर्वर नोड स्टेटस" : "Global Node Status & Latency"}
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 font-mono text-[11px] text-slate-400">
          <div>
            © {new Date().getFullYear()} Crux Cloud. All rights reserved.
          </div>

          <div className="flex items-center gap-4">
            <span className="text-emerald-400">99.99% Uptime SLA</span>
            <span>•</span>
            <span className="text-slate-300">AMD EPYC 9654 / Ryzen 9</span>
            <span>•</span>
            <span className="text-cyan-400">Mumbai • Singapore • Frankfurt • Virginia</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
