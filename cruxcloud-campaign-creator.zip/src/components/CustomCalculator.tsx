import React, { useState } from "react";
import { Language, Currency, HostingPlan, HostingCategory } from "../types";
import { playMinecraftClick, playLevelUpSound } from "../utils/audio";
import { Sparkles, Cpu, HardDrive, Zap, Globe, Check, ArrowRight, Bot } from "lucide-react";

interface Props {
  language: Language;
  currency: Currency;
  onDeployCustomPlan: (plan: HostingPlan) => void;
}

export const CustomCalculator: React.FC<Props> = ({
  language,
  currency,
  onDeployCustomPlan,
}) => {
  const isHi = language === "hi";

  const [ramGB, setRamGB] = useState<number>(4);
  const [cpuCores, setCpuCores] = useState<number>(2);
  const [storageGB, setStorageGB] = useState<number>(60);
  const [selectedLocation, setSelectedLocation] = useState<string>("in-mum-01");
  const [serverType, setServerType] = useState<HostingCategory>("bot");

  // Calculate pricing based on sliders
  // RAM: ₹75 / $0.95 per GB
  // CPU: ₹60 / $0.75 per core
  // Storage: ₹1.2 / $0.015 per GB
  const priceINR = Math.round(ramGB * 75 + cpuCores * 60 + storageGB * 1.2);
  const priceUSD = parseFloat((priceINR / 80).toFixed(2));

  const handleDeploy = () => {
    playLevelUpSound();
    const typeLabel = serverType === "bot" ? "Bot Server" : serverType === "vps" ? "Cloud VPS" : "Web Cloud";
    const customPlan: HostingPlan = {
      id: `custom-${Date.now()}`,
      category: serverType,
      name: `Crux Custom (${ramGB}GB / ${cpuCores} Cores)`,
      nameHi: `क्रुक्स कस्टम (${ramGB}GB / ${cpuCores} कोर)`,
      priceINR,
      priceUSD,
      billingPeriod: "/month",
      ram: `${ramGB} GB DDR5 RAM`,
      cpu: `${cpuCores} vCPU AMD EPYC / Ryzen`,
      storage: `${storageGB} GB Gen4 NVMe`,
      bandwidth: "Unmetered 1Gbps",
      recommendedFor: `Tailored ${typeLabel} Deployment`,
      recommendedForHi: `कस्टम तैयार किया गया ${typeLabel}`,
      features: [
        `${ramGB} GB High-Speed DDR5 RAM`,
        `${cpuCores} Cores AMD EPYC 9654`,
        `${storageGB} GB Enterprise NVMe SSD`,
        "Automated Daily Offsite Backups",
        "2.5 Tbps DDoS Shield Protection",
        "Custom Subdomain (*.cruxcloud.net)",
        "Instant Provisioning (<45s)",
      ],
      featuresHi: [
        `${ramGB} GB हाई-स्पीड DDR5 रैम`,
        `${cpuCores} कोर AMD EPYC 9654`,
        `${storageGB} GB NVMe SSD स्टोरेज`,
        "दैनिक ऑटोमैटिक बैकअप्स",
        "2.5 Tbps DDoS सुरक्षा",
        "कस्टम सबडोमेन (*.cruxcloud.net)",
        "तुरंत 45 सेकंड में एक्टिवेशन",
      ],
      icon: "custom",
    };
    onDeployCustomPlan(customPlan);
  };

  return (
    <section id="calculator" className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
      <div className="rounded-2xl bg-slate-900/65 backdrop-blur-xl border border-white/12 p-6 sm:p-10 shadow-2xl">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-slate-800/80 border border-emerald-500/30 text-xs font-mono text-emerald-300 mb-3 shadow-sm">
            <Sparkles size={13} className="text-amber-400" />
            <span>{isHi ? "कस्टम सर्वर कॉन्फिगरेटर" : "CUSTOM RESOURCE CALCULATOR"}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-2 tracking-tight">
            {isHi ? "अपनी ज़रूरत अनुसार सर्वर तैयार करें" : "Build Your Exact Server Specifications"}
          </h2>

          <p className="text-slate-300 text-xs sm:text-sm">
            {isHi
              ? "रैम, सीपीयू और स्टोरेज को स्लाइड करें और तुरंत रियल-टाइम मूल्य देखें। किसी भी समय 1-क्लिक में अपग्रेड संभव है।"
              : "Adjust RAM, CPU cores, and storage dynamically. Scale seamlessly up or down with zero data loss."}
          </p>

          {/* Type Selector - Smooth rounded pills */}
          <div className="flex justify-center gap-2 mt-6">
            {(["bot", "vps", "web"] as const).map((type) => (
              <button
                key={type}
                onClick={() => {
                  playMinecraftClick();
                  setServerType(type);
                }}
                className={`px-5 py-2 rounded-xl text-xs font-mono font-semibold transition-all cursor-pointer shadow-md ${
                  serverType === type
                    ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-bold border border-emerald-300 scale-105"
                    : "bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white border border-white/10"
                }`}
              >
                {type === "bot"
                  ? isHi
                    ? "1. बॉट होस्टिंग"
                    : "1. Bot Hosting"
                  : type === "vps"
                  ? isHi
                    ? "2. क्लाउड VPS"
                    : "2. Cloud VPS"
                  : isHi
                  ? "3. वेब व ऐप्स"
                  : "3. Web & Apps"}
              </button>
            ))}
          </div>
        </div>

        {/* Sliders Grid + Summary Box */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Sliders Area (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* RAM Slider */}
            <div className="bg-slate-950/60 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-2 font-mono text-xs">
                <span className="text-slate-300 flex items-center gap-1.5">
                  <Zap size={14} className="text-amber-400" />
                  <span>{isHi ? "मेमोरी (RAM DDR5):" : "Memory (RAM DDR5):"}</span>
                </span>
                <span className="text-emerald-300 font-bold text-base">{ramGB} GB</span>
              </div>
              <input
                type="range"
                min="1"
                max="32"
                step="1"
                value={ramGB}
                onChange={(e) => setRamGB(Number(e.target.value))}
                className="w-full accent-emerald-400 h-2 bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-mono text-slate-400 mt-1">
                <span>1 GB</span>
                <span>8 GB</span>
                <span>16 GB</span>
                <span>32 GB</span>
              </div>
            </div>

            {/* CPU Cores Slider */}
            <div className="bg-slate-950/60 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-2 font-mono text-xs">
                <span className="text-slate-300 flex items-center gap-1.5">
                  <Cpu size={14} className="text-cyan-400" />
                  <span>{isHi ? "प्रोसेसर थ्रेड्स (vCPU):" : "Processor (vCPU Cores):"}</span>
                </span>
                <span className="text-cyan-300 font-bold text-base">
                  {cpuCores} {cpuCores === 1 ? "Core" : "Cores"}
                </span>
              </div>
              <input
                type="range"
                min="1"
                max="8"
                step="1"
                value={cpuCores}
                onChange={(e) => setCpuCores(Number(e.target.value))}
                className="w-full accent-cyan-400 h-2 bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-mono text-slate-400 mt-1">
                <span>1 Core</span>
                <span>2 Cores</span>
                <span>4 Cores</span>
                <span>8 Cores</span>
              </div>
            </div>

            {/* NVMe Storage Slider */}
            <div className="bg-slate-950/60 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-2 font-mono text-xs">
                <span className="text-slate-300 flex items-center gap-1.5">
                  <HardDrive size={14} className="text-purple-400" />
                  <span>{isHi ? "स्टोरेज (Enterprise NVMe):" : "Storage (NVMe SSD):"}</span>
                </span>
                <span className="text-purple-300 font-bold text-base">{storageGB} GB</span>
              </div>
              <input
                type="range"
                min="10"
                max="300"
                step="10"
                value={storageGB}
                onChange={(e) => setStorageGB(Number(e.target.value))}
                className="w-full accent-purple-400 h-2 bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-mono text-slate-400 mt-1">
                <span>10 GB</span>
                <span>100 GB</span>
                <span>200 GB</span>
                <span>300 GB</span>
              </div>
            </div>

            {/* Location Selector */}
            <div className="bg-slate-950/60 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
              <span className="text-slate-300 text-xs font-mono mb-2 block flex items-center gap-1.5">
                <Globe size={14} className="text-emerald-400" />
                <span>{isHi ? "सर्वर लोकेशन चुनें:" : "Choose Server Region:"}</span>
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: "in-mum-01", label: "🇮🇳 Mumbai (14ms)" },
                  { id: "sg-sin-01", label: "🇸🇬 Singapore (42ms)" },
                  { id: "de-fra-01", label: "🇩🇪 Frankfurt (110ms)" },
                  { id: "us-iad-01", label: "🇺🇸 Virginia (165ms)" },
                ].map((loc) => (
                  <button
                    key={loc.id}
                    onClick={() => {
                      playMinecraftClick();
                      setSelectedLocation(loc.id);
                    }}
                    className={`p-2 rounded-lg text-[11px] font-mono transition-all cursor-pointer ${
                      selectedLocation === loc.id
                        ? "bg-emerald-500/20 text-emerald-300 border border-emerald-400 font-bold"
                        : "bg-white/5 text-slate-400 hover:bg-white/10 border border-white/5"
                    }`}
                  >
                    {loc.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Pricing & Summary Card (5 cols) - Smooth rounded-2xl glass card */}
          <div className="lg:col-span-5 bg-gradient-to-b from-slate-950/90 to-slate-900/90 p-6 rounded-2xl border-2 border-emerald-400/60 shadow-2xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
                <span className="font-mono text-xs text-slate-400 uppercase">
                  {isHi ? "कस्टम कॉन्फ़िगरेशन सारांश" : "Custom Server Summary"}
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono text-[10px] font-bold">
                  {serverType.toUpperCase()}
                </span>
              </div>

              {/* Price */}
              <div className="mb-6">
                <div className="text-slate-400 text-xs font-mono">{isHi ? "मासिक शुल्क" : "Estimated Monthly Cost"}</div>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-4xl font-extrabold font-mono text-white tracking-tight">
                    {currency === "INR" ? `₹${priceINR}` : `$${priceUSD}`}
                  </span>
                  <span className="text-xs text-slate-400 font-mono">
                    {isHi ? "/माह (कर सहित)" : "/month (incl. tax)"}
                  </span>
                </div>
              </div>

              {/* Spec Checklist */}
              <div className="space-y-2.5 mb-6 text-xs text-slate-200">
                <div className="flex items-center justify-between py-1 border-b border-white/5 font-mono">
                  <span className="text-slate-400">RAM:</span>
                  <span className="text-emerald-300 font-bold">{ramGB} GB DDR5</span>
                </div>
                <div className="flex items-center justify-between py-1 border-b border-white/5 font-mono">
                  <span className="text-slate-400">vCPU:</span>
                  <span className="text-cyan-300 font-bold">{cpuCores} Cores AMD EPYC</span>
                </div>
                <div className="flex items-center justify-between py-1 border-b border-white/5 font-mono">
                  <span className="text-slate-400">Storage:</span>
                  <span className="text-purple-300 font-bold">{storageGB} GB NVMe</span>
                </div>
                <div className="flex items-center justify-between py-1 border-b border-white/5 font-mono">
                  <span className="text-slate-400">Anti-DDoS:</span>
                  <span className="text-emerald-400 font-bold">2.5 Tbps Shield</span>
                </div>
                <div className="flex items-center justify-between py-1 border-b border-white/5 font-mono">
                  <span className="text-slate-400">Subdomain:</span>
                  <span className="text-amber-300 font-bold">Free Included</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleDeploy}
              className="w-full py-3.5 px-4 rounded-xl font-mono text-sm font-bold bg-gradient-to-r from-emerald-400 via-teal-400 to-emerald-500 hover:from-emerald-300 hover:to-teal-300 text-slate-950 flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(16,185,129,0.4)] transition-all cursor-pointer hover:scale-[1.02]"
            >
              <Zap size={16} className="fill-slate-950" />
              <span>{isHi ? "कस्टम सर्वर डिप्लॉय करें" : "Deploy Custom Server"}</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
