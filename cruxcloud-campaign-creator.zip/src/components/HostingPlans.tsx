import React from "react";
import { HostingCategory, HostingPlan, Language, Currency } from "../types";
import { BOT_PLANS, VPS_PLANS, WEB_PLANS } from "../data/hostingData";
import { playMinecraftClick, playLevelUpSound } from "../utils/audio";
import { Check, Zap, Server, Bot, Cpu, Sparkles, Globe, Shield, ArrowRight } from "lucide-react";

interface Props {
  activeCategory: HostingCategory;
  setActiveCategory: (cat: HostingCategory) => void;
  language: Language;
  currency: Currency;
  onSelectPlan: (plan: HostingPlan) => void;
}

export const HostingPlans: React.FC<Props> = ({
  activeCategory,
  setActiveCategory,
  language,
  currency,
  onSelectPlan,
}) => {
  const isHi = language === "hi";

  const getPlans = () => {
    switch (activeCategory) {
      case "bot":
        return BOT_PLANS;
      case "vps":
        return VPS_PLANS;
      case "web":
        return WEB_PLANS;
      default:
        return BOT_PLANS;
    }
  };

  const plans = getPlans();

  const handleTabClick = (cat: HostingCategory) => {
    playMinecraftClick();
    setActiveCategory(cat);
  };

  return (
    <section id="plans" className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Category Tabs Header */}
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/70 backdrop-blur-md border border-emerald-500/30 text-xs font-mono text-emerald-300 mb-3 shadow-lg">
          <Sparkles size={14} className="text-amber-400" />
          <span>{isHi ? "क्रुक्स क्लाउड होस्टिंग प्लान्स व प्राइसेज" : "CRUX CLOUD HOSTING PRODUCTS & PRICING"}</span>
        </div>

        <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight mb-4 drop-shadow-md">
          {isHi ? (
            <>
              अपने अनुकूल <span className="text-emerald-400">सर्वोत्तम सर्वर प्लान</span> चुनें
            </>
          ) : (
            <>
              Choose Your High-Performance <span className="text-emerald-400">Cloud Plan</span>
            </>
          )}
        </h2>

        <p className="text-slate-300 max-w-xl mx-auto text-sm sm:text-base drop-shadow">
          {isHi
            ? "डिस्कॉर्ड बॉट्स, क्लाउड वीपीएस और वेब ऐप्स के लिए उच्च गति वाले AMD नोड्स। सभी प्लान्स में 2.5 Tbps DDoS सुरक्षा व 24/7 अपटाइम शामिल है।"
            : "Enterprise AMD EPYC & Ryzen infrastructure. Instant 45-second provisioning, full root access, unmetered bandwidth, and 2.5 Tbps DDoS shield."}
        </p>

        {/* Tab switcher buttons - Sleek, smooth rounded pills */}
        <div className="flex flex-wrap justify-center gap-3 sm:gap-4 mt-8">
          {/* Bot Hosting Tab */}
          <button
            id="bot-plans-tab"
            onClick={() => handleTabClick("bot")}
            className={`flex items-center gap-2.5 px-6 py-3 rounded-xl font-mono text-xs sm:text-sm font-semibold transition-all duration-300 cursor-pointer backdrop-blur-md shadow-lg ${
              activeCategory === "bot"
                ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-bold shadow-[0_0_25px_rgba(16,185,129,0.45)] border border-emerald-300 scale-105"
                : "bg-slate-900/65 text-slate-300 hover:text-white hover:bg-slate-800/80 border border-white/10 hover:border-emerald-500/40"
            }`}
          >
            <Bot size={17} />
            <span>{isHi ? "1. बोट होस्टिंग (Discord/Telegram)" : "1. Bot Hosting (Discord/Telegram)"}</span>
          </button>

          {/* Cloud VPS Tab */}
          <button
            id="vps-plans-tab"
            onClick={() => handleTabClick("vps")}
            className={`flex items-center gap-2.5 px-6 py-3 rounded-xl font-mono text-xs sm:text-sm font-semibold transition-all duration-300 cursor-pointer backdrop-blur-md shadow-lg ${
              activeCategory === "vps"
                ? "bg-gradient-to-r from-cyan-500 to-blue-500 text-slate-950 font-bold shadow-[0_0_25px_rgba(6,182,212,0.45)] border border-cyan-300 scale-105"
                : "bg-slate-900/65 text-slate-300 hover:text-white hover:bg-slate-800/80 border border-white/10 hover:border-cyan-500/40"
            }`}
          >
            <Cpu size={17} />
            <span>{isHi ? "2. क्लाउड वीपीएस (KVM VPS)" : "2. Cloud VPS (KVM Linux/Windows)"}</span>
          </button>

          {/* Web & App Hosting Tab */}
          <button
            id="web-plans-tab"
            onClick={() => handleTabClick("web")}
            className={`flex items-center gap-2.5 px-6 py-3 rounded-xl font-mono text-xs sm:text-sm font-semibold transition-all duration-300 cursor-pointer backdrop-blur-md shadow-lg ${
              activeCategory === "web"
                ? "bg-gradient-to-r from-purple-500 to-indigo-400 text-white font-bold shadow-[0_0_25px_rgba(168,85,247,0.45)] border border-purple-300 scale-105"
                : "bg-slate-900/65 text-slate-300 hover:text-white hover:bg-slate-800/80 border border-white/10 hover:border-purple-500/40"
            }`}
          >
            <Globe size={17} />
            <span>{isHi ? "3. वेब व ऐप होस्टिंग" : "3. Web & App Cloud (Docker/Node)"}</span>
          </button>
        </div>
      </div>

      {/* Plans Grid - Smooth, sleek rounded-2xl cards with translucent glassmorphic backdrop */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {plans.map((plan) => {
          const price = currency === "INR" ? `₹${plan.priceINR}` : `$${plan.priceUSD}`;
          const isPopular = plan.isPopular;

          return (
            <div
              key={plan.id}
              className={`group relative flex flex-col justify-between rounded-2xl overflow-hidden backdrop-blur-xl transition-all duration-300 shadow-2xl ${
                isPopular
                  ? "bg-slate-900/75 border-2 border-emerald-400/80 shadow-[0_10px_35px_rgba(16,185,129,0.22)] -translate-y-1.5 hover:border-emerald-300"
                  : "bg-slate-900/60 border border-white/12 hover:border-emerald-400/50 hover:bg-slate-900/75 hover:shadow-[0_10px_30px_rgba(16,185,129,0.15)] hover:-translate-y-1"
              }`}
            >
              {/* Sleek Top Accent Gradient Line (smooth, rounded) */}
              <div
                className={`h-1.5 w-full ${
                  isPopular
                    ? "bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400"
                    : "bg-gradient-to-r from-emerald-500/40 via-cyan-500/30 to-purple-500/40 group-hover:from-emerald-400 group-hover:to-cyan-400 transition-all duration-500"
                }`}
              />

              {/* Popular Badge */}
              {isPopular && (
                <div className="absolute top-3.5 right-4">
                  <span className="bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-mono text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-wider shadow-md">
                    {isHi ? (plan.badgeHi || "लोकप्रिय") : (plan.badge || "RECOMMENDED")}
                  </span>
                </div>
              )}

              <div className="p-6">
                {/* Header Title & Non-popular badge */}
                <div className="mb-3">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-lg font-bold text-white tracking-wide">
                      {isHi ? plan.nameHi : plan.name}
                    </h3>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed min-h-[32px]">
                    {isHi ? plan.recommendedForHi : plan.recommendedFor}
                  </p>
                </div>

                {/* Price Display */}
                <div className="py-4 my-2 border-y border-white/10 flex items-baseline gap-1.5">
                  <span className="text-3xl sm:text-4xl font-extrabold font-mono text-white tracking-tight">
                    {price}
                  </span>
                  <span className="text-xs text-slate-400 font-mono">
                    {isHi ? "/माह" : plan.billingPeriod}
                  </span>
                </div>

                {/* Hardware Spec Badges (Smooth rounded-lg pills) */}
                <div className="grid grid-cols-2 gap-2 my-4">
                  <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm">
                    <span className="text-[10px] font-mono text-slate-400 block uppercase">RAM</span>
                    <span className="text-xs font-bold text-emerald-300 font-mono block truncate">
                      {plan.ram}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm">
                    <span className="text-[10px] font-mono text-slate-400 block uppercase">vCPU</span>
                    <span className="text-xs font-bold text-cyan-300 font-mono block truncate">
                      {plan.cpu}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm">
                    <span className="text-[10px] font-mono text-slate-400 block uppercase">Storage</span>
                    <span className="text-xs font-bold text-slate-200 font-mono block truncate">
                      {plan.storage}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm">
                    <span className="text-[10px] font-mono text-slate-400 block uppercase">Network</span>
                    <span className="text-xs font-bold text-purple-300 font-mono block truncate">
                      {plan.bandwidth}
                    </span>
                  </div>
                </div>

                {/* Features List */}
                <div className="space-y-2 mt-4 pt-2">
                  <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 block mb-2 font-semibold">
                    {isHi ? "प्लान में शामिल विशेषताएं:" : "Included Features:"}
                  </span>
                  {(isHi ? plan.featuresHi : plan.features).map((feat, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                      <div className="mt-0.5 w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/40">
                        <Check size={10} strokeWidth={3} />
                      </div>
                      <span className="leading-snug">{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Button - Smooth, rounded-xl button */}
              <div className="p-5 pt-0">
                <button
                  id={`deploy-${plan.id}`}
                  onClick={() => {
                    playLevelUpSound();
                    onSelectPlan(plan);
                  }}
                  className={`w-full py-3 px-4 rounded-xl font-mono text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all duration-300 cursor-pointer shadow-lg ${
                    isPopular
                      ? "bg-gradient-to-r from-emerald-400 via-teal-400 to-emerald-500 text-slate-950 hover:shadow-[0_0_20px_rgba(16,185,129,0.5)] hover:scale-[1.02]"
                      : "bg-white/10 hover:bg-emerald-500 hover:text-slate-950 text-white border border-white/15 hover:border-emerald-400 hover:shadow-[0_0_15px_rgba(16,185,129,0.3)]"
                  }`}
                >
                  <Zap size={14} className={isPopular ? "fill-slate-950" : ""} />
                  <span>{isHi ? "तुरंत डिप्लॉय करें" : "Deploy Server"}</span>
                  <ArrowRight size={14} />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
