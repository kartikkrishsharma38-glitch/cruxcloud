import React, { useState } from "react";
import { Language, Currency, HostingCategory } from "../types";
import { playMinecraftClick, playLevelUpSound } from "../utils/audio";
import { Bot, Cpu, ShieldCheck, Zap, Copy, Check, Sparkles, Terminal, Activity, Globe, ArrowRight } from "lucide-react";

interface Props {
  language: Language;
  currency: Currency;
  onSelectCategory: (cat: HostingCategory) => void;
  onOpenDeployModal: () => void;
  onOpenAiChat: () => void;
  onOpenBannerStudio: () => void;
}

export const Hero: React.FC<Props> = ({
  language,
  currency,
  onSelectCategory,
  onOpenDeployModal,
  onOpenAiChat,
  onOpenBannerStudio,
}) => {
  const isHi = language === "hi";
  const [copied, setCopied] = useState(false);

  const handleCopyEndpoint = () => {
    playLevelUpSound();
    navigator.clipboard.writeText("edge.cruxcloud.net");
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section className="relative z-10 pt-12 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Top Tag - Smooth rounded-full pill */}
      <div className="flex justify-center mb-6">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-emerald-500/30 text-emerald-300 text-xs font-mono shadow-[0_0_20px_rgba(16,185,129,0.2)]">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>{isHi ? "क्रुक्स क्लाउड 2026 • 5.7GHz AMD EPYC व राइज़न 9 DDR5 सर्वर" : "CRUX CLOUD 2026 • AMD EPYC 9654 & RYZEN 9 • 2.5 TBPS ANTI-DDOS"}</span>
        </div>
      </div>

      {/* Main Headline */}
      <div className="text-center max-w-4xl mx-auto mb-8">
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white mb-6 leading-tight drop-shadow-[0_4px_16px_rgba(0,0,0,0.9)]">
          {isHi ? (
            <>
              सुपरफास्ट <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 drop-shadow-[0_2px_12px_rgba(16,185,129,0.5)]">बॉट होस्टिंग</span>, क्लाउड वीपीएस और वेब सर्वर
            </>
          ) : (
            <>
              High-Performance <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 drop-shadow-[0_2px_12px_rgba(16,185,129,0.5)]">Bot Hosting</span>, Cloud VPS & Web Apps
            </>
          )}
        </h1>

        <div className="inline-block p-0.5 rounded-2xl bg-slate-950/60 backdrop-blur-md border border-white/12 shadow-xl">
          <p className="text-sm sm:text-base text-slate-200 max-w-2xl mx-auto leading-relaxed px-5 py-2.5 font-medium">
            {isHi
              ? "डिस्कॉर्ड बॉट्स, टेलीग्राम बॉट्स, केवीएम वीपीएस और वेब सेवाओं के लिए निर्मित। 45 सेकंड में तुरंत एक्टिवेशन, अनमीटर्ड बैंडविड्थ और 24/7 क्रुक्स AI असिस्टेंट।"
              : "Built for ultra-fast response, zero downtime, and instant 45-second provisioning. Power your Discord bots, Python/Node.js apps, Docker stacks, and KVM Cloud VPS with enterprise NVMe speed."}
          </p>
        </div>
      </div>

      {/* Hero Interactive Server Status & Ping Bar - Smooth rounded-2xl glass card */}
      <div className="max-w-3xl mx-auto mb-12 p-0.5 rounded-2xl bg-gradient-to-r from-emerald-500/40 via-cyan-500/30 to-purple-500/40 shadow-2xl">
        <div className="bg-slate-950/80 backdrop-blur-xl p-4 sm:p-5 rounded-2xl border border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Edge Network Endpoint */}
          <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center shrink-0 shadow-inner">
              <Globe size={22} className="text-emerald-400" />
            </div>
            <div>
              <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                {isHi ? "लाइव एज नोड एंडपॉइंट" : "Edge Network Endpoint"}
              </div>
              <div className="font-mono text-sm sm:text-base text-white font-semibold flex items-center gap-2">
                <span>edge.cruxcloud.net</span>
                <span className="text-[10px] px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full font-sans">
                  Anycast HTTP/3
                </span>
              </div>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="flex items-center justify-between sm:justify-end gap-5 w-full md:w-auto text-xs font-mono">
            <div className="text-left">
              <div className="text-slate-400 text-[10px]">{isHi ? "नोड स्थिति" : "Network Status"}</div>
              <div className="text-emerald-300 font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                100% Online
              </div>
            </div>

            <div className="text-left border-l border-white/10 pl-4">
              <div className="text-slate-400 text-[10px]">{isHi ? "मुंबई लेटेंसी" : "Mumbai Latency"}</div>
              <div className="text-cyan-300 font-bold">14 ms</div>
            </div>

            <button
              onClick={handleCopyEndpoint}
              className="px-3.5 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-200 text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 shadow-sm"
              title="Click to copy endpoint"
            >
              {copied ? (
                <>
                  <Check size={14} className="text-emerald-400" />
                  <span>{isHi ? "कॉपी हुआ!" : "Copied!"}</span>
                </>
              ) : (
                <>
                  <Copy size={14} className="text-emerald-400" />
                  <span>{isHi ? "कॉपी करें" : "Copy"}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Main 3 Category Quick Select Cards - Smooth rounded-2xl translucent cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto mb-12">
        {/* 1. Bot Hosting Card */}
        <div
          onClick={() => {
            playMinecraftClick();
            onSelectCategory("bot");
            const el = document.getElementById("plans");
            el?.scrollIntoView({ behavior: "smooth" });
          }}
          className="group relative cursor-pointer p-6 rounded-2xl bg-slate-900/65 backdrop-blur-xl border border-white/12 hover:border-emerald-400/60 shadow-2xl hover:bg-slate-900/80 transition-all duration-300 overflow-hidden hover:-translate-y-1"
        >
          {/* Sleek top accent line */}
          <div className="h-1.5 w-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-500 absolute top-0 left-0 right-0 rounded-t-2xl" />

          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform shadow-md">
              <Bot size={24} />
            </div>
            <span className="text-xs font-mono px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full font-bold">
              {currency === "INR" ? "₹79/माह से" : "From $0.99/mo"}
            </span>
          </div>

          <h2 className="text-xl font-bold text-white mb-2 group-hover:text-emerald-300 transition-colors flex items-center gap-2">
            <span>{isHi ? "बॉट होस्टिंग" : "Bot Hosting"}</span>
            <span className="text-xs font-normal text-slate-400 font-mono">24/7 Online</span>
          </h2>

          <p className="text-sm text-slate-300 mb-5 leading-relaxed">
            {isHi
              ? "Node.js, Python, Java, Lavalink। GitHub ऑटो-डिप्लॉय, ऑटो-रीस्टार्ट, लाइव वेब कंसोल और फ्री डेटाबेस।"
              : "Discord & Telegram bot hosting with zero downtime, instant Git push deploy, audio streaming, and live logs."}
          </p>

          <div className="flex items-center text-xs font-mono text-emerald-400 font-semibold group-hover:translate-x-1.5 transition-transform">
            <span>{isHi ? "बॉट प्लान्स देखें" : "View Bot Plans"}</span>
            <ArrowRight size={14} className="ml-1" />
          </div>
        </div>

        {/* 2. VPS Hosting Card */}
        <div
          onClick={() => {
            playMinecraftClick();
            onSelectCategory("vps");
            const el = document.getElementById("plans");
            el?.scrollIntoView({ behavior: "smooth" });
          }}
          className="group relative cursor-pointer p-6 rounded-2xl bg-slate-900/65 backdrop-blur-xl border border-white/12 hover:border-cyan-400/60 shadow-2xl hover:bg-slate-900/80 transition-all duration-300 overflow-hidden hover:-translate-y-1"
        >
          {/* Sleek top accent line */}
          <div className="h-1.5 w-full bg-gradient-to-r from-cyan-500 via-sky-400 to-blue-500 absolute top-0 left-0 right-0 rounded-t-2xl" />

          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition-transform shadow-md">
              <Cpu size={24} />
            </div>
            <span className="text-xs font-mono px-2.5 py-1 bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 rounded-full font-bold">
              {currency === "INR" ? "₹449/माह से" : "From $5.99/mo"}
            </span>
          </div>

          <h2 className="text-xl font-bold text-white mb-2 group-hover:text-cyan-300 transition-colors flex items-center gap-2">
            <span>{isHi ? "क्लाउड वीपीएस (VPS)" : "Cloud VPS"}</span>
            <span className="text-xs font-normal text-slate-400 font-mono">Full Root</span>
          </h2>

          <p className="text-sm text-slate-300 mb-5 leading-relaxed">
            {isHi
              ? "KVM वर्चुअलाइजेशन, AMD EPYC 9654 प्रोसेसर, Gen4 NVMe स्टोरेज, डेडिकेटेड IPv4 और 1-क्लिक OS रीइंस्टॉल।"
              : "Enterprise KVM cloud virtual servers with Ubuntu/Debian/Windows, dedicated IPv4, snapshots, and 2.5 Tbps shield."}
          </p>

          <div className="flex items-center text-xs font-mono text-cyan-400 font-semibold group-hover:translate-x-1.5 transition-transform">
            <span>{isHi ? "वीपीएस प्लान्स देखें" : "View VPS Plans"}</span>
            <ArrowRight size={14} className="ml-1" />
          </div>
        </div>

        {/* 3. Web & App Cloud Card */}
        <div
          onClick={() => {
            playMinecraftClick();
            onSelectCategory("web");
            const el = document.getElementById("plans");
            el?.scrollIntoView({ behavior: "smooth" });
          }}
          className="group relative cursor-pointer p-6 rounded-2xl bg-slate-900/65 backdrop-blur-xl border border-white/12 hover:border-purple-400/60 shadow-2xl hover:bg-slate-900/80 transition-all duration-300 overflow-hidden hover:-translate-y-1"
        >
          {/* Sleek top accent line */}
          <div className="h-1.5 w-full bg-gradient-to-r from-purple-500 via-fuchsia-400 to-indigo-500 absolute top-0 left-0 right-0 rounded-t-2xl" />

          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 group-hover:scale-105 transition-transform shadow-md">
              <Globe size={24} />
            </div>
            <span className="text-xs font-mono px-2.5 py-1 bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-full font-bold">
              {currency === "INR" ? "₹149/माह से" : "From $1.99/mo"}
            </span>
          </div>

          <h2 className="text-xl font-bold text-white mb-2 group-hover:text-purple-300 transition-colors flex items-center gap-2">
            <span>{isHi ? "वेब व ऐप्स होस्टिंग" : "Web & App Cloud"}</span>
            <span className="text-xs font-normal text-slate-400 font-mono">Free SSL</span>
          </h2>

          <p className="text-sm text-slate-300 mb-5 leading-relaxed">
            {isHi
              ? "Full-stack Node.js, Python, PHP, Docker और डेटाबेस। फ्री वाइल्डकार्ड SSL, ग्लोबल CDN और 1-क्लिक स्टेजिंग।"
              : "Host full-stack web applications, REST APIs, databases, and Docker microservices with automated free SSL & Git integration."}
          </p>

          <div className="flex items-center text-xs font-mono text-purple-400 font-semibold group-hover:translate-x-1.5 transition-transform">
            <span>{isHi ? "वेब प्लान्स देखें" : "View Web Plans"}</span>
            <ArrowRight size={14} className="ml-1" />
          </div>
        </div>
      </div>

      {/* Feature Pills Bar - Smooth rounded-xl items */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-4xl mx-auto pt-4 border-t border-white/10 text-center">
        <div className="flex items-center justify-center gap-2 text-xs font-mono text-slate-300 p-2.5 rounded-xl bg-slate-900/60 backdrop-blur-md border border-white/10 shadow-sm">
          <Zap size={14} className="text-amber-400" />
          <span>{isHi ? "<45 सेकंड एक्टिवेशन" : "Instant 45s Setup"}</span>
        </div>

        <div className="flex items-center justify-center gap-2 text-xs font-mono text-slate-300 p-2.5 rounded-xl bg-slate-900/60 backdrop-blur-md border border-white/10 shadow-sm">
          <ShieldCheck size={14} className="text-emerald-400" />
          <span>{isHi ? "2.5 Tbps DDoS शील्ड" : "2.5 Tbps DDoS Shield"}</span>
        </div>

        <div className="flex items-center justify-center gap-2 text-xs font-mono text-slate-300 p-2.5 rounded-xl bg-slate-900/60 backdrop-blur-md border border-white/10 shadow-sm">
          <Activity size={14} className="text-cyan-400" />
          <span>{isHi ? "99.99% अपटाइम SLA" : "99.99% Uptime SLA"}</span>
        </div>

        <div className="flex items-center justify-center gap-2 text-xs font-mono text-slate-300 p-2.5 rounded-xl bg-slate-900/60 backdrop-blur-md border border-white/10 shadow-sm">
          <Terminal size={14} className="text-purple-400" />
          <span>{isHi ? "फुल रूट + वेब कंसोल" : "Full Root + Web Console"}</span>
        </div>
      </div>
    </section>
  );
};
