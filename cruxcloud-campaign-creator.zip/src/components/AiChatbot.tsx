import React, { useState, useRef, useEffect } from "react";
import { ChatMessage, GeminiChatModel, Language } from "../types";
import { playMinecraftClick, playLevelUpSound } from "../utils/audio";
import {
  MessageSquareCode,
  Send,
  X,
  Bot,
  Sparkles,
  RefreshCw,
  Cpu,
  Zap,
  Terminal,
  HelpCircle,
  Minimize2,
  Trash2,
} from "lucide-react";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const AiChatbot: React.FC<Props> = ({ isOpen, onClose, language }) => {
  const isHi = language === "hi";

  const [model, setModel] = useState<GeminiChatModel>("gemini-3.5-flash");
  const [role, setRole] = useState<string>("architect");
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const initialWelcomeMessage: ChatMessage = {
    id: "welcome-1",
    role: "model",
    text: isHi
      ? "नमस्ते! मैं क्रुक्स AI हूँ—क्रुक्स क्लाउड का सर्वर आर्किटेक्ट। मैं आपको सही माइनक्राफ्ट रैम चुनने, प्लगइन/क्रैश लॉग फिक्स करने या बॉट होस्ट करने में मदद कर सकता हूँ। आप क्या जानना चाहते हैं?"
      : "Greetings! I'm Crux AI, your technical server architect and support companion for Crux Cloud. I can help recommend RAM for your player count, troubleshoot Paper/Purpur TPS lag, or configure your Discord bot. How can I help you today?",
    timestamp: Date.now(),
  };

  const [messages, setMessages] = useState<ChatMessage[]>([initialWelcomeMessage]);

  useEffect(() => {
    setMessages((prev) => {
      if (prev.length === 1 && prev[0].id === "welcome-1") {
        return [initialWelcomeMessage];
      }
      return prev;
    });
  }, [language]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  if (!isOpen) return null;

  const getRoleContext = () => {
    switch (role) {
      case "diagnostic":
        return "You are Crux AI specialized in Minecraft Server Crash Diagnostics & TPS Optimization. Help users analyze crash reports, stack traces, spark profiles, and configure paper.yml / spigot.yml for maximum performance. Provide exact config snippets.";
      case "bot_specialist":
        return "You are Crux AI specialized in Discord & Telegram Bot Engineering. Help users write code in discord.js or discord.py, set up 24/7 bot daemons, FFmpeg/Lavalink audio streaming, and manage environment variables.";
      default:
        return "You are Crux AI, the lead Server Architect for Crux Cloud. Guide users to the best Minecraft server, Bot hosting, or Cloud VPS plans based on their player count, modpacks, and technical requirements.";
    }
  };

  const handleSendMessage = async (customText?: string) => {
    const textToSend = (customText || input).trim();
    if (!textToSend || loading) return;

    playMinecraftClick();
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      text: textToSend,
      timestamp: Date.now(),
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInput("");
    setLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: newHistory.map((m) => ({ role: m.role, text: m.text })),
          model,
          roleContext: getRoleContext(),
        }),
      });

      if (!response.ok) {
        throw new Error(`Chat API error: ${response.statusText}`);
      }

      const data = await response.json();
      playLevelUpSound();

      const botMsg: ChatMessage = {
        id: `model-${Date.now()}`,
        role: "model",
        text: data.reply || "I am here to help you configure your Crux Cloud server. Ask me anything!",
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err: any) {
      console.error(err);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: "model",
        text: isHi
          ? `माफ़ करें, अनुरोध प्रोसेस करने में त्रुटि आई: ${err.message}. कृपया पुनः प्रयास करें।`
          : `Apologies, I encountered an issue connecting to the AI node: ${err.message}. Please try again.`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleClearChat = () => {
    playMinecraftClick();
    setMessages([initialWelcomeMessage]);
  };

  const samplePrompts = isHi
    ? [
        "20 प्लेयर्स के लिए कितनी रैम चाहिए?",
        "PaperMC में TPS लैग कैसे ठीक करें?",
        "डिस्कॉर्ड म्यूजिक बोट कैसे चलाएं?",
        "GeyserMC से मोबाइल प्लेयर्स कैसे कनेक्ट करें?",
      ]
    : [
        "How much RAM for 20 players on 1.21.4?",
        "How do I fix TPS lag on PaperMC?",
        "How to host a 24/7 Discord Python bot?",
        "Crossplay setup with Geyser for Bedrock?",
      ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl h-[88vh] max-h-[750px] bg-[#0c1424] border-2 border-cyan-500/80 rounded-xs shadow-[0_0_50px_rgba(6,182,212,0.3)] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="p-3.5 bg-gradient-to-r from-[#0d1c33] via-[#0b172a] to-[#0d1c33] border-b border-cyan-500/30 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xs bg-cyan-500/20 border border-cyan-500/50 flex items-center justify-center text-cyan-300">
              <Bot size={18} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white font-mono flex items-center gap-1.5">
                  <span>CRUX AI SERVER ARCHITECT</span>
                  <span className="text-[10px] text-emerald-400 bg-emerald-500/20 px-1.5 py-0.2 rounded-xs">
                    ACTIVE
                  </span>
                </h3>
              </div>
              <p className="text-[11px] text-slate-400">
                {isHi ? "24/7 तकनीकी सहायता व सर्वर गाइड" : "Multi-turn Gemini intelligence for Crux Cloud"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleClearChat}
              title="Clear chat history"
              className="p-1.5 rounded-xs text-slate-400 hover:text-red-400 hover:bg-white/5 transition-colors cursor-pointer"
            >
              <Trash2 size={16} />
            </button>
            <button
              onClick={() => {
                playMinecraftClick();
                onClose();
              }}
              className="p-1.5 rounded-xs text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Model & Role Controls Bar */}
        <div className="px-3.5 py-2 bg-black/40 border-b border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
          {/* Gemini Model Selector */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 text-[11px] flex items-center gap-1">
              <Cpu size={12} className="text-cyan-400" />
              <span>Model:</span>
            </span>
            <select
              value={model}
              onChange={(e) => setModel(e.target.value as GeminiChatModel)}
              className="bg-[#09121f] text-cyan-300 border border-cyan-500/40 rounded-xs px-2 py-1 text-[11px] focus:outline-hidden"
            >
              <option value="gemini-3.5-flash">gemini-3.5-flash (General - Recommended)</option>
              <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Fast & Lightweight)</option>
              <option value="gemini-3.1-pro-preview">gemini-3.1-pro-preview (Complex & Reasoning)</option>
            </select>
          </div>

          {/* Role Persona */}
          <div className="flex items-center gap-1">
            <span className="text-slate-400 text-[11px]">Role:</span>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="bg-[#09121f] text-slate-200 border border-white/20 rounded-xs px-2 py-1 text-[11px] focus:outline-hidden"
            >
              <option value="architect">Server Architect</option>
              <option value="diagnostic">Crash Log Diagnostics</option>
              <option value="bot_specialist">Discord/Bot Specialist</option>
            </select>
          </div>
        </div>

        {/* Scrollable Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 font-sans text-sm">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              {msg.role === "model" && (
                <div className="w-7 h-7 rounded-xs bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 flex items-center justify-center shrink-0 mt-0.5">
                  <Bot size={15} />
                </div>
              )}

              <div
                className={`max-w-[85%] p-3.5 rounded-xs leading-relaxed ${
                  msg.role === "user"
                    ? "bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-medium shadow-sm"
                    : "bg-[#080e1a] border border-white/10 text-slate-200 shadow-sm"
                }`}
              >
                <div className="whitespace-pre-wrap font-sans text-xs sm:text-sm">
                  {msg.text}
                </div>
                <div className="text-[10px] font-mono text-slate-400 mt-1.5 opacity-60 text-right">
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </div>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-3 items-center text-slate-400 text-xs font-mono">
              <div className="w-7 h-7 rounded-xs bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 flex items-center justify-center shrink-0">
                <RefreshCw size={14} className="animate-spin text-cyan-400" />
              </div>
              <span className="flex items-center gap-1.5">
                <span>Crux AI thinking via {model}...</span>
              </span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-3 py-1.5 bg-black/20 border-t border-white/5 flex gap-1.5 overflow-x-auto no-scrollbar">
          {samplePrompts.map((promptText, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(promptText)}
              disabled={loading}
              className="text-[11px] font-mono px-2.5 py-1 rounded-xs bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 hover:border-cyan-400/50 shrink-0 transition-colors cursor-pointer"
            >
              {promptText}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="p-3 bg-[#08101d] border-t border-white/10 flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              isHi
                ? "माइनक्राफ्ट सर्वर या बॉट के बारे में कुछ भी पूछें..."
                : "Ask anything about server sizing, crash logs, or bot setup..."
            }
            className="flex-1 bg-[#0e192c] border border-white/10 rounded-xs px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-400 placeholder:text-slate-500 font-sans"
            disabled={loading}
          />

          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="px-4 py-2.5 rounded-xs bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-black font-mono font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-[0_0_12px_rgba(6,182,212,0.4)] cursor-pointer"
          >
            <span>{isHi ? "भेजें" : "SEND"}</span>
            <Send size={13} />
          </button>
        </form>
      </div>
    </div>
  );
};
