import React, { useState } from "react";
import { ImageResolution, Language, GeneratedVisual } from "../types";
import { playMinecraftClick, playLevelUpSound } from "../utils/audio";
import { Image as ImageIcon, Sparkles, Download, RefreshCw, X, Sliders, Check, Layers } from "lucide-react";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const BannerStudio: React.FC<Props> = ({ isOpen, onClose, language }) => {
  const isHi = language === "hi";

  const [prompt, setPrompt] = useState(
    "Cinematic Minecraft server banner, floating mystical islands, diamond fortress, glowing nether portal, volumetric twilight fog, 4k ultra detailed gaming concept art"
  );
  const [size, setSize] = useState<ImageResolution>("1K");
  const [aspectRatio, setAspectRatio] = useState<string>("16:9");
  const [loading, setLoading] = useState(false);
  const [generatedVisuals, setGeneratedVisuals] = useState<GeneratedVisual[]>([]);
  const [activeVisual, setActiveVisual] = useState<GeneratedVisual | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const samplePresets = [
    {
      title: isHi ? "माइनक्राफ्ट सर्वर बैनर" : "SMP Server Banner",
      prompt: "Epic Minecraft SMP server banner, lush mountain village, players exploring, diamond armor, dynamic sky, vibrant shaders",
    },
    {
      title: isHi ? "नेदर पोर्टल फोर्ट्रेस" : "Nether Fortress",
      prompt: "Menacing Nether fortress, basalt pillars, glowing crimson lava falls, purple dimensional rift portal, volumetric embers",
    },
    {
      title: isHi ? "डिस्कॉर्ड बोट थंबनेल" : "Discord Bot Artwork",
      prompt: "Futuristic robotic redstone bot holding a glowing neon diamond, cyberpunk voxel laboratory, clean mascot illustration",
    },
    {
      title: isHi ? "स्काईब्लॉक आइलैंड्स" : "Skyblock Islands",
      prompt: "Magical floating Minecraft Skyblock island with waterfalls flowing into the void, cherry blossom tree, glowing ore nodes",
    },
  ];

  const handleGenerate = async () => {
    if (!prompt.trim() || loading) return;

    playMinecraftClick();
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          size, // 1K, 2K, or 4K per requirement!
          aspectRatio,
        }),
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || `Generation failed (${response.status})`);
      }

      const data = await response.json();
      if (!data.imageUrl) {
        throw new Error("No image data returned from model.");
      }

      playLevelUpSound();

      const newVisual: GeneratedVisual = {
        id: `img-${Date.now()}`,
        prompt,
        size,
        imageUrl: data.imageUrl,
        createdAt: Date.now(),
      };

      setGeneratedVisuals((prev) => [newVisual, ...prev]);
      setActiveVisual(newVisual);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to generate visual.");
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = (visual: GeneratedVisual) => {
    playMinecraftClick();
    const link = document.createElement("a");
    link.href = visual.imageUrl;
    link.download = `crux-cloud-${visual.size.toLowerCase()}-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs">
      <div className="relative w-full max-w-4xl h-[90vh] max-h-[820px] bg-[#0c1324] border-2 border-purple-500/80 rounded-xs shadow-[0_0_50px_rgba(168,85,247,0.3)] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-[#170f29] via-[#110d21] to-[#170f29] border-b border-purple-500/30 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xs bg-purple-500/20 border border-purple-500/50 flex items-center justify-center text-purple-300">
              <ImageIcon size={18} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white font-mono flex items-center gap-1.5">
                  <span>CRUX AI BANNER & VISUALS STUDIO</span>
                  <span className="text-[10px] text-purple-300 bg-purple-500/20 px-1.5 py-0.2 rounded-xs">
                    gemini-3-pro-image-preview
                  </span>
                </h3>
              </div>
              <p className="text-[11px] text-slate-400">
                {isHi ? "माइनक्राफ्ट सर्वर बैनर, पोस्टर व 4K विज़ुअल्स जनरेटर" : "High-resolution campaign visuals, server MOTDs & artwork"}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              playMinecraftClick();
              onClose();
            }}
            className="p-1.5 rounded-xs text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content Body (2 Columns) */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-y-auto">
          {/* Left Controls (5 cols) */}
          <div className="lg:col-span-5 p-5 border-r border-white/10 space-y-5 bg-[#080e1b]">
            {/* Resolution Size Affordance (1K, 2K, 4K) */}
            <div>
              <label className="block text-xs font-mono text-slate-300 mb-2 flex items-center gap-1.5 font-bold">
                <Sliders size={14} className="text-purple-400" />
                <span>{isHi ? "इमेज रिज़ॉल्यूशन (Size):" : "Image Resolution (Affordance):"}</span>
              </label>
              <div className="grid grid-cols-3 gap-2 font-mono text-xs">
                {(["1K", "2K", "4K"] as ImageResolution[]).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => {
                      playMinecraftClick();
                      setSize(s);
                    }}
                    className={`py-2 px-3 rounded-xs border text-center transition-all cursor-pointer ${
                      size === s
                        ? "bg-purple-600 text-white border-purple-400 font-bold shadow-[0_0_12px_rgba(168,85,247,0.4)]"
                        : "bg-white/5 border-white/10 text-slate-300 hover:bg-white/10"
                    }`}
                  >
                    <div>{s}</div>
                    <div className="text-[9px] opacity-70">
                      {s === "1K" ? "1024px" : s === "2K" ? "2048px" : "4096px Ultra"}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Aspect Ratio */}
            <div>
              <label className="block text-xs font-mono text-slate-300 mb-2 flex items-center gap-1.5 font-bold">
                <Layers size={14} className="text-cyan-400" />
                <span>{isHi ? "आस्पेक्ट रेशियो (Ratio):" : "Aspect Ratio:"}</span>
              </label>
              <div className="grid grid-cols-3 gap-2 font-mono text-xs">
                {[
                  { id: "16:9", label: "16:9 Banner" },
                  { id: "1:1", label: "1:1 Square" },
                  { id: "4:3", label: "4:3 Classic" },
                ].map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => {
                      playMinecraftClick();
                      setAspectRatio(r.id);
                    }}
                    className={`py-1.5 px-2 rounded-xs border text-center transition-all cursor-pointer ${
                      aspectRatio === r.id
                        ? "bg-cyan-600 text-white border-cyan-400 font-bold shadow-[0_0_10px_rgba(6,182,212,0.4)]"
                        : "bg-white/5 border-white/10 text-slate-300 hover:bg-white/10"
                    }`}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Prompt Input */}
            <div>
              <label className="block text-xs font-mono text-slate-300 mb-2 font-bold">
                {isHi ? "विज़ुअल विवरण (Prompt):" : "Visual Description / Prompt:"}
              </label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                rows={4}
                className="w-full bg-[#0d1627] border border-white/15 rounded-xs p-3 text-xs text-white placeholder:text-slate-500 focus:outline-hidden focus:border-purple-400 font-sans"
                placeholder="Describe your desired Minecraft server banner, campaign visual or icon..."
              />
            </div>

            {/* Presets */}
            <div>
              <div className="text-[11px] font-mono text-slate-400 mb-2 uppercase">
                {isHi ? "त्वरित टेम्पलेट्स:" : "Sample Presets:"}
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {samplePresets.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      playMinecraftClick();
                      setPrompt(p.prompt);
                    }}
                    className="text-left p-2 rounded-xs bg-white/5 hover:bg-purple-900/30 border border-white/5 hover:border-purple-500/40 text-[11px] text-slate-300 truncate transition-colors cursor-pointer"
                  >
                    {p.title}
                  </button>
                ))}
              </div>
            </div>

            {/* Error banner */}
            {error && (
              <div className="p-2.5 rounded-xs bg-red-900/40 border border-red-500/50 text-xs text-red-300">
                {error}
              </div>
            )}

            {/* Generate Action Button */}
            <button
              onClick={handleGenerate}
              disabled={loading || !prompt.trim()}
              className="w-full py-3 px-4 rounded-xs bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 text-white font-mono font-bold text-xs uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(168,85,247,0.4)] cursor-pointer flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <RefreshCw size={14} className="animate-spin text-white" />
                  <span>Generating {size} Visual...</span>
                </>
              ) : (
                <>
                  <Sparkles size={14} />
                  <span>
                    {isHi ? `जनरेट करें (${size})` : `GENERATE VISUAL (${size})`}
                  </span>
                </>
              )}
            </button>
          </div>

          {/* Right Visual Stage & Gallery (7 cols) */}
          <div className="lg:col-span-7 p-6 bg-[#060b14] flex flex-col justify-between">
            {/* Main Stage */}
            <div className="flex-1 flex flex-col items-center justify-center">
              {loading ? (
                <div className="text-center p-8">
                  <div className="w-16 h-16 rounded-xs bg-purple-500/20 border-2 border-purple-400 mx-auto flex items-center justify-center mb-4 animate-pulse shadow-[0_0_30px_rgba(168,85,247,0.5)]">
                    <Sparkles size={32} className="text-purple-400 animate-spin" />
                  </div>
                  <h4 className="text-sm font-bold text-white font-mono mb-1">
                    Synthesizing {size} Minecraft Artwork...
                  </h4>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto">
                    Gemini image engine is generating shaders, lighting, and textures.
                  </p>
                </div>
              ) : activeVisual ? (
                <div className="w-full h-full flex flex-col items-center justify-center">
                  <div className="relative group max-h-[460px] max-w-full rounded-xs overflow-hidden border border-purple-500/50 shadow-2xl bg-black">
                    <img
                      src={activeVisual.imageUrl}
                      alt={activeVisual.prompt}
                      referrerPolicy="no-referrer"
                      className="max-h-[440px] w-auto object-contain"
                    />

                    <div className="absolute top-2 right-2 px-2 py-1 rounded-xs bg-black/70 backdrop-blur-xs font-mono text-[10px] text-purple-300 border border-purple-400/40">
                      {activeVisual.size} RESOLUTION
                    </div>
                  </div>

                  <div className="w-full mt-4 flex items-center justify-between gap-2">
                    <div className="text-xs text-slate-400 truncate max-w-md font-sans">
                      {activeVisual.prompt}
                    </div>

                    <button
                      onClick={() => handleDownload(activeVisual)}
                      className="px-4 py-2 rounded-xs bg-emerald-500 hover:bg-emerald-400 text-black font-mono font-bold text-xs uppercase flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 shadow-md"
                    >
                      <Download size={14} />
                      <span>{isHi ? "डाउनलोड करें" : "DOWNLOAD"}</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-center p-8 border border-dashed border-white/10 rounded-xs max-w-md">
                  <ImageIcon size={40} className="text-slate-600 mx-auto mb-3" />
                  <h4 className="text-sm font-bold text-slate-300 font-mono mb-1">
                    {isHi ? "कोई विज़ुअल जनरेट नहीं किया गया" : "No Visual Generated Yet"}
                  </h4>
                  <p className="text-xs text-slate-500">
                    {isHi
                      ? "बाईं ओर विवरण और रिज़ॉल्यूशन (1K, 2K, 4K) चुनें और जनरेट बटन दबाएं।"
                      : "Choose a size affordance (1K, 2K, or 4K), enter a prompt or preset, and click Generate."}
                  </p>
                </div>
              )}
            </div>

            {/* Generated History Strip */}
            {generatedVisuals.length > 0 && (
              <div className="mt-6 pt-4 border-t border-white/10">
                <div className="text-[11px] font-mono text-slate-400 mb-2 uppercase">
                  {isHi ? "हाल के विज़ुअल्स:" : "Recent Generations:"}
                </div>
                <div className="flex gap-2 overflow-x-auto pb-2">
                  {generatedVisuals.map((v) => (
                    <button
                      key={v.id}
                      onClick={() => setActiveVisual(v)}
                      className={`relative w-20 h-14 rounded-xs overflow-hidden border shrink-0 transition-all cursor-pointer ${
                        activeVisual?.id === v.id
                          ? "border-purple-400 scale-105 shadow-md"
                          : "border-white/10 opacity-70 hover:opacity-100"
                      }`}
                    >
                      <img
                        src={v.imageUrl}
                        alt="thumbnail"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute bottom-0 right-0 px-1 text-[8px] font-mono bg-black/80 text-white">
                        {v.size}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
