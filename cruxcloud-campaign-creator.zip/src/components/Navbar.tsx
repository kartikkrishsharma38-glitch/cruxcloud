import React from "react";
import { Currency, Language, MinecraftThemeMode } from "../types";
import { playMinecraftClick, playPortalSound } from "../utils/audio";
import { Volume2, VolumeX, Sparkles, Bot, Cpu, Globe, MessageSquareCode, Image as ImageIcon } from "lucide-react";
import { BrandLogo } from "./BrandLogo";

interface Props {
  theme: MinecraftThemeMode;
  setTheme: (theme: MinecraftThemeMode) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  currency: Currency;
  setCurrency: (curr: Currency) => void;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  onOpenAiChat: () => void;
  onOpenBannerStudio: () => void;
  onOpenDeployModal: () => void;
}

export const Navbar: React.FC<Props> = ({
  theme,
  setTheme,
  language,
  setLanguage,
  currency,
  setCurrency,
  soundEnabled,
  setSoundEnabled,
  onOpenAiChat,
  onOpenBannerStudio,
  onOpenDeployModal,
}) => {
  const isHi = language === "hi";

  const handleThemeChange = (newTheme: MinecraftThemeMode) => {
    if (newTheme === "nether") {
      playPortalSound();
    } else {
      playMinecraftClick();
    }
    setTheme(newTheme);
  };

  const handleCurrencyToggle = () => {
    playMinecraftClick();
    setCurrency(currency === "INR" ? "USD" : "INR");
  };

  const handleLanguageToggle = () => {
    playMinecraftClick();
    setLanguage(language === "hi" ? "en" : "hi");
  };

  const handleSoundToggle = () => {
    setSoundEnabled(!soundEnabled);
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-slate-950/75 border-b border-emerald-500/20 shadow-xl transition-colors">
      {/* Top micro banner */}
      <div className="bg-gradient-to-r from-emerald-950/70 via-slate-900/80 to-purple-950/70 text-xs py-1 px-4 border-b border-white/5 flex items-center justify-between text-slate-300">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="font-mono text-[11px] tracking-wide truncate">
            {isHi
              ? "क्रुक्स क्लाउड नोड्स ऑनलाइन (मुंबई • सिंगापुर • फ्रैंकफर्ट • वर्जीनिया) — AMD EPYC 9654"
              : "CRUX CLOUD NODES ONLINE: AMD EPYC 9654 & Ryzen 9 • 2.5Tbps Anti-DDoS • 99.9% Uptime"}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Audio toggle */}
          <button
            onClick={handleSoundToggle}
            className="flex items-center gap-1 text-[11px] hover:text-emerald-400 transition-colors cursor-pointer"
            title={soundEnabled ? "Mute game SFX" : "Enable game SFX"}
          >
            {soundEnabled ? <Volume2 size={13} className="text-emerald-400" /> : <VolumeX size={13} className="text-slate-500" />}
            <span className="hidden sm:inline font-mono">{soundEnabled ? "SFX: ON" : "SFX: OFF"}</span>
          </button>

          {/* Currency Toggle */}
          <button
            onClick={handleCurrencyToggle}
            className="px-2.5 py-0.5 rounded-lg bg-white/5 hover:bg-white/10 text-emerald-300 font-mono text-[11px] transition-colors border border-emerald-500/30 cursor-pointer"
          >
            {currency === "INR" ? "₹ INR" : "$ USD"}
          </button>

          {/* Language Toggle */}
          <button
            onClick={handleLanguageToggle}
            className="px-2.5 py-0.5 rounded-lg bg-white/5 hover:bg-white/10 text-amber-300 font-mono text-[11px] transition-colors border border-amber-500/30 cursor-pointer"
          >
            {isHi ? "English" : "हिन्दी"}
          </button>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        {/* Brand Logo with the user-provided icon */}
        <a
          href="#"
          onClick={() => playMinecraftClick()}
          className="flex items-center gap-3 group focus:outline-hidden"
        >
          {/* User's exact Brand Logo Icon */}
          <BrandLogo size={42} className="group-hover:scale-105 transition-transform duration-300 ring-2 ring-emerald-400/50" />

          <div>
            <div className="flex items-center gap-2">
              <span className="font-['Silkscreen',monospace] text-xl font-bold tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-white drop-shadow-[0_2px_8px_rgba(16,185,129,0.4)]">
                CRUX CLOUD
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded-full font-bold">
                PRO
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-sans tracking-wide">
              {isHi ? "हाई-परफॉरमेंस बॉट व वीपीएस क्लाउड" : "High-Performance Bot & Cloud VPS"}
            </p>
          </div>
        </a>

        {/* Navigation items (No Minecraft server) */}
        <nav className="hidden lg:flex items-center gap-1.5 text-sm font-medium text-slate-300">
          <a
            href="#plans"
            onClick={() => playMinecraftClick()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl hover:text-emerald-300 hover:bg-emerald-500/10 transition-colors"
          >
            <Bot size={15} className="text-emerald-400" />
            <span>{isHi ? "बॉट होस्टिंग" : "Bot Hosting"}</span>
          </a>

          <a
            href="#plans"
            onClick={() => playMinecraftClick()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl hover:text-cyan-300 hover:bg-cyan-500/10 transition-colors"
          >
            <Cpu size={15} className="text-cyan-400" />
            <span>{isHi ? "क्लाउड VPS" : "Cloud VPS"}</span>
          </a>

          <a
            href="#plans"
            onClick={() => playMinecraftClick()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl hover:text-purple-300 hover:bg-purple-500/10 transition-colors"
          >
            <Globe size={15} className="text-purple-400" />
            <span>{isHi ? "वेब व ऐप्स" : "Web & Apps"}</span>
          </a>

          <a
            href="#calculator"
            onClick={() => playMinecraftClick()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl hover:text-amber-300 hover:bg-amber-500/10 transition-colors"
          >
            <Sparkles size={15} className="text-amber-400" />
            <span>{isHi ? "कैलकुलेटर" : "Custom Builder"}</span>
          </a>

          <a
            href="#locations"
            onClick={() => playMinecraftClick()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl hover:text-slate-100 hover:bg-white/5 transition-colors"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>{isHi ? "नोड्स व पिंग" : "Global Nodes"}</span>
          </a>
        </nav>

        {/* Action Controls & Theme selector */}
        <div className="flex items-center gap-2.5">
          {/* Theme Atmosphere Switcher */}
          <div className="flex items-center bg-slate-900/80 border border-white/10 p-1 rounded-xl shadow-inner">
            <button
              onClick={() => handleThemeChange("overworld_night")}
              title="Overworld Night"
              className={`px-2 py-1 text-xs rounded-lg transition-all cursor-pointer ${
                theme === "overworld_night"
                  ? "bg-cyan-600/60 text-cyan-200 border border-cyan-400/50 shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              🌙
            </button>
            <button
              onClick={() => handleThemeChange("overworld_day")}
              title="Overworld Day"
              className={`px-2 py-1 text-xs rounded-lg transition-all cursor-pointer ${
                theme === "overworld_day"
                  ? "bg-amber-600/60 text-amber-200 border border-amber-400/50 shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              ☀️
            </button>
            <button
              onClick={() => handleThemeChange("nether")}
              title="Nether Realm"
              className={`px-2 py-1 text-xs rounded-lg transition-all cursor-pointer ${
                theme === "nether"
                  ? "bg-red-700/70 text-red-200 border border-red-500/60 shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              🔥
            </button>
          </div>

          {/* AI Banner Studio Button */}
          <button
            onClick={() => {
              playMinecraftClick();
              onOpenBannerStudio();
            }}
            className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-900/40 hover:bg-purple-800/60 text-purple-200 border border-purple-500/40 text-xs font-mono transition-all cursor-pointer shadow-[0_0_12px_rgba(168,85,247,0.2)]"
            title="Generate custom server banners & 4K artwork with Gemini"
          >
            <ImageIcon size={14} className="text-purple-400" />
            <span>{isHi ? "AI बैनर" : "4K Studio"}</span>
          </button>

          {/* AI Chatbot Assistant Button */}
          <button
            onClick={() => {
              playMinecraftClick();
              onOpenAiChat();
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-900/40 hover:bg-cyan-800/60 text-cyan-200 border border-cyan-500/40 text-xs font-mono transition-all cursor-pointer shadow-[0_0_12px_rgba(6,182,212,0.2)]"
            title="Chat with Crux AI Server Architect"
          >
            <MessageSquareCode size={14} className="text-cyan-400" />
            <span className="hidden md:inline">{isHi ? "AI सपोर्ट" : "Crux AI"}</span>
          </button>

          {/* Deploy Server CTA */}
          <button
            onClick={() => {
              playMinecraftClick();
              onOpenDeployModal();
            }}
            className="relative group overflow-hidden px-4.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold text-xs tracking-wide uppercase transition-all shadow-[0_0_20px_rgba(16,185,129,0.4)] cursor-pointer"
          >
            <span className="relative z-10 font-mono flex items-center gap-1.5">
              <span>{isHi ? "डिप्लॉय करें" : "DEPLOY NOW"}</span>
              <span className="group-hover:translate-x-0.5 transition-transform">→</span>
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
