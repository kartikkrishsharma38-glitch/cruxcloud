import React, { useEffect, useRef } from "react";
import { MinecraftThemeMode } from "../types";

interface Props {
  theme: MinecraftThemeMode;
}

export const MinecraftBackground: React.FC<Props> = ({ theme }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener("resize", handleResize);

    interface Sparkle {
      x: number;
      y: number;
      size: number;
      speedY: number;
      speedX: number;
      opacity: number;
      color: string;
      pulse: number;
    }

    const sparkles: Sparkle[] = [];
    const count = 35;

    const getSparkleColors = () => {
      if (theme === "nether") {
        return ["#f97316", "#ef4444", "#fbbf24", "#dc2626"];
      } else if (theme === "overworld_day") {
        return ["#34d399", "#60a5fa", "#facc15", "#a7f3d0"];
      } else {
        // overworld_night
        return ["#38bdf8", "#34d399", "#a855f7", "#818cf8"];
      }
    };

    const colors = getSparkleColors();

    for (let i = 0; i < count; i++) {
      sparkles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 3 + 1.5,
        speedY: (Math.random() - 0.5) * 0.4 - 0.2,
        speedX: (Math.random() - 0.5) * 0.3,
        opacity: Math.random() * 0.6 + 0.2,
        color: colors[Math.floor(Math.random() * colors.length)],
        pulse: Math.random() * Math.PI * 2,
      });
    }

    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      sparkles.forEach((s) => {
        s.y += s.speedY;
        s.x += s.speedX;
        s.pulse += 0.03;

        if (s.y < 0) s.y = height;
        if (s.y > height) s.y = 0;
        if (s.x < 0) s.x = width;
        if (s.x > width) s.x = 0;

        const currentOpacity = s.opacity + Math.sin(s.pulse) * 0.2;

        ctx.save();
        ctx.fillStyle = s.color;
        ctx.globalAlpha = Math.max(0.1, Math.min(0.9, currentOpacity));
        // Draw crisp diamond/pixel spark
        ctx.fillRect(s.x, s.y, s.size, s.size);
        ctx.restore();
      });

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [theme]);

  const getOverlayClasses = () => {
    switch (theme) {
      case "nether":
        return "bg-amber-950/15";
      case "overworld_day":
        return "bg-transparent";
      case "overworld_night":
      default:
        return "bg-transparent";
    }
  };

  return (
    <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden select-none">
      {/* User Uploaded Minecraft Wallpaper Background Image: Normal brightness, natural colors, 10% blur (approx 2px) */}
      <img
        src="/assets/minecraft-bg.jpg"
        alt="Minecraft World Background"
        className="absolute inset-0 w-full h-full object-cover object-center filter blur-[2px] transform scale-105 transition-all duration-500"
      />

      {/* Clean overlay without darkness */}
      <div className={`absolute inset-0 transition-colors duration-500 ${getOverlayClasses()}`} />

      {/* Floating Ambient Sparks Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
    </div>
  );
};
