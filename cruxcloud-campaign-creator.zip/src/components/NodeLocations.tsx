import React, { useState, useEffect } from "react";
import { Language, NodeLocation } from "../types";
import { SERVER_LOCATIONS } from "../data/hostingData";
import { playMinecraftClick } from "../utils/audio";
import { Globe, Activity, Shield, Cpu, RefreshCw, CheckCircle2 } from "lucide-react";

interface Props {
  language: Language;
}

export const NodeLocations: React.FC<Props> = ({ language }) => {
  const isHi = language === "hi";
  const [nodes, setNodes] = useState<NodeLocation[]>(SERVER_LOCATIONS);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const refreshPings = async () => {
    setIsRefreshing(true);
    playMinecraftClick();
    try {
      const res = await fetch("/api/nodes");
      if (res.ok) {
        const data = await res.json();
        if (data.nodes) {
          setNodes(data.nodes);
        }
      }
    } catch (e) {
      setNodes((prev) =>
        prev.map((n) => ({
          ...n,
          ping: Math.max(10, n.ping + Math.floor((Math.random() - 0.5) * 6)),
          load: Math.min(95, Math.max(20, n.load + Math.floor((Math.random() - 0.5) * 8))),
        }))
      );
    } finally {
      setTimeout(() => setIsRefreshing(false), 600);
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setNodes((prev) =>
        prev.map((n) => ({
          ...n,
          ping: Math.max(10, n.ping + Math.floor((Math.random() - 0.5) * 4)),
        }))
      );
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="locations" className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-8">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-cyan-500/30 text-xs font-mono text-cyan-300 mb-2 shadow-sm">
            <Globe size={13} />
            <span>{isHi ? "ग्लोबल सर्वर नोड्स व रियल-टाइम पिंग" : "GLOBAL CLOUD NODES & REAL-TIME LATENCY"}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {isHi ? "अल्ट्रा-लो लेटेंसी ग्लोबल नेटवर्क" : "Enterprise Low-Latency Global Nodes"}
          </h2>
        </div>

        <button
          onClick={refreshPings}
          disabled={isRefreshing}
          className="px-4 py-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 backdrop-blur-md border border-white/12 text-xs font-mono text-slate-300 flex items-center gap-2 transition-colors cursor-pointer shadow-sm"
        >
          <RefreshCw size={13} className={isRefreshing ? "animate-spin text-emerald-400" : "text-slate-400"} />
          <span>{isHi ? "पिंग रीफ्रेश करें" : "Refresh Latency"}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {nodes.map((node) => (
          <div
            key={node.id}
            className="p-5 rounded-2xl bg-slate-900/65 backdrop-blur-xl border border-white/12 hover:border-cyan-500/50 hover:bg-slate-900/80 transition-all duration-300 group shadow-xl hover:-translate-y-1"
          >
            {/* Header with Flag and Code */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <span className="text-2xl">{node.flag}</span>
                <div>
                  <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {node.name}
                  </h3>
                  <span className="text-[10px] font-mono text-slate-400">{node.code}</span>
                </div>
              </div>

              <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono font-semibold">
                <CheckCircle2 size={11} />
                <span>ONLINE</span>
              </div>
            </div>

            {/* Ping Indicator */}
            <div className="p-3 bg-slate-950/60 rounded-xl border border-white/5 mb-4 flex items-center justify-between font-mono">
              <span className="text-xs text-slate-400 flex items-center gap-1.5">
                <Activity size={13} className="text-cyan-400" />
                <span>{isHi ? "लेटेंसी" : "Ping"}</span>
              </span>
              <span
                className={`text-sm font-bold ${
                  node.ping < 50
                    ? "text-emerald-400"
                    : node.ping < 120
                    ? "text-amber-400"
                    : "text-purple-400"
                }`}
              >
                {node.ping} ms
              </span>
            </div>

            {/* Specs */}
            <div className="space-y-2 text-xs font-mono text-slate-300">
              <div className="flex items-start gap-1.5 text-[11px]">
                <Cpu size={13} className="text-slate-500 shrink-0 mt-0.5" />
                <span className="text-slate-400 truncate">{node.cpu}</span>
              </div>
              <div className="flex items-start gap-1.5 text-[11px]">
                <Shield size={13} className="text-emerald-500 shrink-0 mt-0.5" />
                <span className="text-slate-400 truncate">{node.ddosProtection}</span>
              </div>
            </div>

            {/* Load bar */}
            <div className="mt-4 pt-3 border-t border-white/5">
              <div className="flex justify-between text-[10px] font-mono text-slate-400 mb-1.5">
                <span>{isHi ? "नोड लोड" : "Node Capacity"}</span>
                <span>{node.load}%</span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div
                  className="h-full bg-cyan-400 transition-all duration-500 rounded-full"
                  style={{ width: `${node.load}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
