export type HostingCategory = "bot" | "vps" | "web";

export type Currency = "INR" | "USD";

export type Language = "hi" | "en";

export type MinecraftThemeMode = "overworld_night" | "overworld_day" | "nether";

export interface HostingPlan {
  id: string;
  category: HostingCategory;
  name: string;
  nameHi: string;
  badge?: string;
  badgeHi?: string;
  isPopular?: boolean;
  priceINR: number;
  priceUSD: number;
  billingPeriod: string;
  ram: string;
  cpu: string;
  storage: string;
  bandwidth: string;
  recommendedFor: string;
  recommendedForHi: string;
  features: string[];
  featuresHi: string[];
  icon: string;
}

export interface NodeLocation {
  id: string;
  name: string;
  flag: string;
  code: string;
  cpu: string;
  ram: string;
  storage: string;
  ddosProtection: string;
  ping: number;
  status: "operational" | "maintenance";
  load: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "model";
  text: string;
  timestamp: number;
}

export type GeminiChatModel = "gemini-3.5-flash" | "gemini-3.1-flash-lite" | "gemini-3.1-pro-preview";

export type ImageResolution = "1K" | "2K" | "4K";

export interface GeneratedVisual {
  id: string;
  prompt: string;
  size: ImageResolution;
  imageUrl: string;
  createdAt: number;
}
